#include <jni.h>
#include <string>
#include <android/log.h>

#define TAG "native-lib"

extern "C" JNIEXPORT jstring JNICALL
Java_com_example_ssss_NativeLib_stringFromJNI(JNIEnv *env, jclass /* clazz */) {
    std::string hello = "Hello from C++";
    __android_log_print(ANDROID_LOG_INFO, TAG, "%s", hello.c_str());
    return env->NewStringUTF(hello.c_str());
}
