package com.example;

import android.app.Activity;
import android.os.Bundle;
import android.view.Gravity;
import android.widget.TextView;

public class MainActivity extends Activity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        TextView t = new TextView(this);
        t.setGravity(Gravity.CENTER);
        t.setTextSize(22);
        t.setText(NativeLib.stringFromJNI());
        setContentView(t);
    }
}
