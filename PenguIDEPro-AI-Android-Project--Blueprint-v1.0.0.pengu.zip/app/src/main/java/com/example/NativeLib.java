package com.example;

public class NativeLib {

    static {
        System.loadLibrary("native-lib");
    }

    /** Implemented in app/src/main/cpp/native-lib.cpp */
    public static native String stringFromJNI();
}
