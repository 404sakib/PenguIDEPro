# Apk File Structure

Package: `com.example.apkfilestructure`

Created with Pengu IDE Pro.
